chrome.storage.local.get(['stats', 'relayId'], (data) => {
  const stats = data.stats || {};
  const dot = document.getElementById('dot');
  const statusText = document.getElementById('status-text');

  if (stats.connected) {
    dot.classList.add('on');
    statusText.textContent = 'Connected — earning credits';
  } else {
    statusText.textContent = 'Disconnected — reconnecting...';
  }

  document.getElementById('relays').textContent = (stats.relays || 0).toLocaleString();
  document.getElementById('credits').textContent = (stats.credits || 0).toLocaleString() + ' free calls';

  const relayId = data.relayId;
  if (relayId) {
    document.getElementById('relay-id').textContent = 'Relay ID: ' + relayId.slice(0, 20) + '...';
  }
});
