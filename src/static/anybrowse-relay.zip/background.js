const WS_URL = 'wss://anybrowse.dev/relay-ws';
let ws = null;
let relayId = null;
let stats = { relays: 0, credits: 0, connected: false };

async function getRelayId() {
  return new Promise(resolve => {
    chrome.storage.local.get(['relayId'], r => resolve(r.relayId || null));
  });
}

function saveStats() {
  chrome.storage.local.set({ stats });
}

async function connect() {
  relayId = await getRelayId();

  if (!relayId) {
    try {
      const resp = await fetch('https://anybrowse.dev/relay/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}'
      });
      const data = await resp.json();
      relayId = data.relayId;
      chrome.storage.local.set({ relayId });
    } catch (e) {
      setTimeout(connect, 60000);
      return;
    }
  }

  try {
    ws = new WebSocket(WS_URL);

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'register', relayId }));
      stats.connected = true;
      saveStats();
      chrome.action.setBadgeText({ text: '●' });
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    };

    ws.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data);

        if (msg.type === 'fetch' && msg.url && msg.requestId) {
          try {
            const resp = await fetch(msg.url, {
              credentials: 'omit',
              headers: { 'Accept': 'text/html,application/xhtml+xml,*/*' }
            });
            const html = await resp.text();
            ws.send(JSON.stringify({ type: 'result', requestId: msg.requestId, html, status: resp.status }));
            stats.relays++;
            stats.credits++;
            saveStats();
          } catch (e) {
            ws.send(JSON.stringify({ type: 'result', requestId: msg.requestId, html: '', status: 0 }));
          }
        }
      } catch (e) {}
    };

    ws.onclose = () => {
      stats.connected = false;
      saveStats();
      chrome.action.setBadgeText({ text: '' });
      setTimeout(connect, 30000);
    };

    ws.onerror = () => { try { ws.close(); } catch(e) {} };

  } catch (e) {
    setTimeout(connect, 60000);
  }
}

chrome.runtime.onInstalled.addListener(() => connect());
chrome.runtime.onStartup.addListener(() => connect());

chrome.alarms.create('keepalive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepalive') {
    if (!ws || ws.readyState === WebSocket.CLOSED || ws.readyState === WebSocket.CLOSING) {
      connect();
    }
  }
});
